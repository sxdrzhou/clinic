<?php

// 服务器配置信息
$config = array(
    'db' => array(
        'servername' => 'localhost',
        'username' => 'root',
        'password' => '6024402',
        'dbname' => 'sydb',
        'charset' => 'utf8mb4'
    ),
    'app' => array(
        'name' => '',
        'version' => '',
        'initialized' => 0 // 已初始化
    )
);
?>