<?php
// 简单的PHP信息测试文件
phpinfo();
?>